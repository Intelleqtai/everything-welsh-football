"""Independent verification: recompute every published statistic straight from matches.csv
by a separate code path and compare with output/data.json. Any mismatch is a failure."""
import json, numpy as np, pandas as pd
D=json.load(open("output/data.json"))
m=pd.read_csv("output/matches.csv",parse_dates=["date"])
m["excluded"]=m.excluded.fillna("")
d=m[(m.excluded=="")&m.attendance.notna()].copy()
fails=[];checks=0
def chk(name,got,exp,tol=0.005):
    global checks; checks+=1
    ok = (abs(got-exp)<=tol*max(1,abs(exp))) if isinstance(exp,(int,float)) and not isinstance(exp,bool) else got==exp
    if not ok: fails.append(f"{name}: page={exp} recomputed={got}")
    return ok

# --- headline counts ---
chk("fixtures",len(d),D["meta"]["fixtures"],0)
chk("total attendance",int(d.attendance.sum()),D["meta"]["total"],0)
chk("mean",round(d.attendance.mean()),D["meta"]["mean"],0)
chk("median",int(d.attendance.median()),D["meta"]["median"],0)
chk("max",int(d.attendance.max()),D["meta"]["max"],0)
chk("clubs",d.home.nunique(),D["meta"]["clubs"],0)
chk("missing",int(((m.excluded=="")&m.attendance.isna()).sum()),D["meta"]["missing"],0)

# --- index is truly attendance / own season home average ---
rec=d.groupby(["season","home"]).attendance.transform("mean")
chk("attendance_index definition",float((d.attendance/rec-d.attendance_index).abs().max()),0.0,1e-9)

# --- every block: index, raw, n ---
def block(col,rows,label,filt=None):
    src=d if filt is None else filt
    for r in rows:
        g=src[src[col].astype(str)==r["k"]]
        chk(f"{label}[{r['k']}].n",len(g),r["n"],0)
        chk(f"{label}[{r['k']}].idx",round(float(g.attendance_index.mean()),3),r["idx"],0.002)
        if "raw" in r and r["raw"] is not None:
            chk(f"{label}[{r['k']}].raw",round(float(g.attendance.mean())),r["raw"],0.01)
block("travel_band",D["travel"],"travel")
block("kick_off_band",D["kickoff"],"kickoff")
block("fixture_type",D["region"],"region")
block("month",D["month"],"month")
d["bh_lbl"]=d.bank_holiday.fillna("Ordinary fixture"); block("bh_lbl",D["bh"],"bh")
d["derby_lbl"]=np.where(d.derby==1,"Derby (under 45 min)","Everything else"); block("derby_lbl",D["derby"],"derby")
d["sh"]=d.school_holiday.fillna("Term time"); block("sh",D["school"],"school")
d["cl"]=d.clash.map({0:"No clash",1:"Big club at home"}); block("cl",D["clash"],"clash")
block("wx_cond",D["wx_cond"],"weather")

# --- day of week: raw, adjusted, long-haul share ---
mix=d.travel_band.value_counts(normalize=True)
cell=d.pivot_table(index="day_of_week",columns="travel_band",values="attendance_index",aggfunc="mean")
wts=(cell.notna()*mix); adj=(cell.fillna(0)*mix).sum(axis=1)/wts.sum(axis=1)
for r in D["day"]:
    g=d[d.day_of_week==r["k"]]
    chk(f"day[{r['k']}].n",len(g),r["n"],0)
    chk(f"day[{r['k']}].raw",round(float(g.attendance_index.mean()),3),r["raw"],0.002)
    chk(f"day[{r['k']}].adj",round(float(adj[r['k']]),3),r["adj"],0.002)
    chk(f"day[{r['k']}].far",round(float((g.travel_band==">3h").mean()*100)),r["far"],0.01)

# --- season trend ---
for r in D["trend"]:
    g=d[d.season==r["k"]]
    chk(f"trend[{r['k']}].n",len(g),r["n"],0)
    chk(f"trend[{r['k']}].mean",round(float(g.attendance.mean())),r["mean"],0.01)
    chk(f"trend[{r['k']}].total",int(g.attendance.sum()),r["total"],0)

# --- first / last home game ---
d2=d.sort_values("date").copy()
d2["gm"]=d2.groupby(["season","home"]).cumcount()+1
d2["tot"]=d2.groupby(["season","home"]).home.transform("size")
d2["slot"]=np.where(d2.gm==1,"First home game",np.where(d2.gm==d2.tot,"Last home game","Everything else"))
block("slot",D["firstlast"],"firstlast",d2)

# --- Friday vs Saturday within band ---
for r in D["frisat"]:
    for day in ["friday","saturday"]:
        g=d[(d.day_of_week==day.capitalize())&(d.travel_band==r["band"])]
        chk(f"frisat[{r['band']}].{day}_n",len(g),r[day+"_n"],0)
        if r[day] is not None:
            chk(f"frisat[{r['band']}].{day}",round(float(g.attendance_index.mean()),3),r[day],0.002)

# --- clash confound percentages ---
c1=d[d.clash==1]
chk("clash sat_pct",round(float((c1.day_of_week=="Saturday").mean()*100)),D["clash_mix"]["sat_pct"],0.01)
chk("clash far_pct",round(float((c1.travel_band==">3h").mean()*100)),D["clash_mix"]["far_pct"],0.01)

# --- expansion, matched window ---
d["sy"]=d.season.str[:4].astype(int)
w=d[(d.date>=pd.to_datetime(dict(year=d.sy,month=7,day=25)))&(d.date<=pd.to_datetime(dict(year=d.sy,month=9,day=9)))]
a=w[w.season=="2025-2026"].groupby("home").attendance.mean(); b=w[w.season=="2026-2027"].groupby("home").attendance.mean()
lf=pd.concat([a,b],axis=1).dropna(); lf.columns=["p","n"]; ch=(lf.n/lf.p-1)*100
chk("expansion n",len(lf),D["expansion_stats"]["n"],0)
chk("expansion median",round(float(ch.median())),D["expansion_stats"]["median"],0.01)

# --- opponent pull + club table spot checks ---
for r in D["pull"]:
    g=d[d.away==r["k"]]; chk(f"pull[{r['k']}].n",len(g),r["n"],0)
    chk(f"pull[{r['k']}].idx",round(float(g.attendance_index.mean()),3),r["idx"],0.002)
for r in D["clubs"]:
    g=d[d.home==r["k"]]; chk(f"club[{r['k']}].avg",round(float(g.attendance.mean())),r["avg"],0.01)
    chk(f"club[{r['k']}].n",len(g),r["n"],0)

# --- biggest crowds ---
top=d.nlargest(len(D["top"]),"attendance")
for i,r in enumerate(D["top"]):
    chk(f"top[{i}].att",int(top.iloc[i].attendance),r["att"],0)
    chk(f"top[{i}].home",top.iloc[i].home,r["home"])

print(f"{checks} checks run")
if fails:
    print(f"\n{len(fails)} MISMATCHES:")
    for f in fails[:40]: print("  ",f)
else:
    print("ALL AGGREGATE CHECKS PASSED - regression verification is separate")

if fails: raise SystemExit(1)
